
<?php

# Enable Error Reporting and Display:
//error_reporting(~0);
//ini_set('display_errors', 1);

$url = "http://doctor.skynets.site:8080/doctorHack/hs/GetDoctor/V1/c2ba7196-9a98-11e9-9ed4-001d7d98a0eb";

if (isset($_POST["txt"])){ 
	$url = trim($_POST["txt"]);
	$url = "http://doctor.skynets.site:8080/doctorHack/hs/GetDoctor/V1/".$url;
}     
//echo '<p>'.$url.'</p>';

$jsonData = file_get_contents($url);
echo $jsonData;


?>
