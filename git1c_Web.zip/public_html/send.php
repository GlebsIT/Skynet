<?php
header('Access-Control-Allow-Origin: *');

if (isset($_POST["ValueButton"])){ 
	$ValueButton = trim($_POST["ValueButton"]);
}
if (isset($_POST["ValueComment"])){ 
	$ValueComment = trim($_POST["ValueComment"]);
}
if (isset($_POST["ValueGuid"])){ 
	$ValueGuid = trim($_POST["ValueGuid"]);
}

$url = 'http://doctor.skynets.site:8080/doctorHack/hs/Otziv/Post';

//$json = '{"login":"userLogin","password":"baf8636b0fb7e0c3fd1e6a809e89238cfa8825be"}';
/*
$json = '{"Mark":"'.$ValueButton.'","Comment":"'.$ValueComment.'","Guid":"'.$ValueGuid.'"}';
if ($curl = curl_init()) {
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query(['out'=>$json]));
    $response = curl_exec($curl);
    curl_close($curl);
}
*/

$data = array('Mark' => $ValueButton, 'Comment' => $ValueComment, 'Guid' => $ValueGuid);

// use key 'http' even if you send the request to https://...
$options = array(
    'http' => array(
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data)
    )
);
$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);
if ($result === FALSE) { /* Handle error */ }

var_dump($result);
?>