<html>
    <form  method="post" id="ajax_form" action="" >
		  <div class="form-group">
			<label for="exampleFormControlTextarea1">Текст для кодирования</label>
			<textarea name="name" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
		  </div>
		    <input class="btn btn-primary" type="button" id="btn" value="Отправить" />
   		   <input class="btn btn-primary" type="button" id="clears" value="Очистить" />
	</form>
	
	<div id="result_form"></div>
    
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script>
        
    	$(document).ready(function() {
    		$("#btn").click(
    			function(){
    			    sendAjaxForm('#result_form', document.getElementById('exampleFormControlTextarea1').value, 'GeneratorQRCode.php');
    				return false; 
    			}
    		);
          
        $("#clears").click(
    			function(){
    				$("#exampleFormControlTextarea1").val("");
    				return false; 
    			}
    		);
    	});
    	
    	function sendAjaxForm(result_form, ValueTextArea, url) {
			$.ajax({
				url:      url,    //url страницы (action_ajax_form.php)
				type:     "POST", //метод отправки
				dataType: "text", //формат данных
				data: {
				    "ValueTextArea": ValueTextArea
				},
				success: function(response) {    //Данные отправлены успешно
					$(result_form).html(response);
				},
				error: function(response) {      // Данные не отправлены
					$(result_form).html('Ошибка. Данные не отправлены.');
				}
			});
		}

    </script>
</html>