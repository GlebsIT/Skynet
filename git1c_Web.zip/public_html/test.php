<?php
file_put_contents('file.txt', json_encode($_POST));
 echo 'working';
?>