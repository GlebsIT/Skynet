<!doctype html>
<html lang="en">
    <head>
        <p>
            <script type="text/javascript" src="llqrcode.js"></script>
            <script type="text/javascript" src="webqr.js"></script>
            <script type="text/javascript" src="jquery-1.8.0.min.js"></script>
            
            <script>
                $(document).ready(function() {
                    load();
                    setimg(); 
                	//setwebcam();
                });
            </script>
            
            <div id="main">
                <div id="mainbody">
                    <div id="outdiv"></div>
                    <div id="result"></div>
                </div>
            </div>           
            <canvas id="qr-canvas"></canvas>        
        </p>            
  </body>
</html>