# Пример навыка Алисы для Python

Инструкция по развертыванию навыка на сервисе Now приведена в [документации Яндекс.Диалогов](https://tech.yandex.ru/dialogs/alice/doc/quickstart-python-docpage/).