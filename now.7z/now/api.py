# coding: utf-8
# Импортирует поддержку UTF-8.
from __future__ import unicode_literals

import re
import requests
import smtplib
import datetime
d=datetime.datetime.today()
n=datetime.datetime.now() 
x=str(d.day)+'-'+str(d.month)+'-'+str(d.year)+'\n'
x+='Время приёма: '+str(n.hour)+':'+str(n.minute)+'\n'

 
from email.mime.multipart import MIMEMultipart      
from email.mime.text import MIMEText
# Импортируем модули для работы с JSON и логами.
import json
import logging

# Импортируем подмодули Flask для запуска веб-сервиса.
from flask import Flask, request
import requests
app = Flask(__name__)


logging.basicConfig(level=logging.DEBUG)

# Хранилище данных о сессиях.
sessionStorage = {}

f=open('card.txt','r')

# Задаем параметры приложения Flask.
@app.route("/", methods=['POST'])

def main():
# Функция получает тело запроса и возвращает ответ.
    logging.info('Request: %r', request.json)
    

    response = {
        "version": request.json['version'],
        "session": request.json['session'],
        "response": {
            "end_session": False
        }
    }

    handle_dialog(request.json, response)

    logging.info('Response: %r', response)

    return json.dumps(
        response,
        ensure_ascii=False,
        indent=2
    )

# Функция для непосредственной обработки диалога.
def handle_dialog(req, res):
    user_id = req['session']['user_id']
    global x


    if req['session']['new']:
        # Это новый пользователь.
        # Инициализируем сессию и поприветствуем его.

        sessionStorage[user_id] = {
            'suggests': [
                "Да",
                "Зачем это нужно?",
                "Причина обращения",
                "Недомогание началось...",
                "Сейчас я чувувствую себя...",
                "Это всё",
                "Запись завершена",
                
            ]
        }

        res['response']['text'] = 'Добрый вечер! Я голосовой помшник врача. Скажите, пожалуйста, согласны ли вы на запись приема?'
        x+='Пациент: '+str(user_id)[-5:]+'\n'
        res['response']['buttons'] = get_suggests(user_id)
        return 

    if req['request']['original_utterance'].lower() in [
        'это обязательно?',
        'это обязательно',
        'зачем',
        'зачем?',
        'а зачем?',
        'зачем это нужно',
        'а зачем?',
        'а зачем это нужно?',
        'зачем это нужно?',
    ]:
        
        res['response']['text'] ='Это не обязательно, но у врача будет больше времени на постановку диагноза. Попробуем?' 
        res['response']['buttons'] = get_suggests(user_id)
        return 
    if req['request']['original_utterance'].lower() in [
        'нет',
        'я против',
        'не хочу',
        'не буду',
    ]:
        res['response']['text'] ='Ничего страшного. Будем работать по старинке. Хотя это помогло бы врачу... ' 
        return 
    if req['request']['original_utterance'].lower() in [
        'да',
        'хорошо',
        'давайте',
        'ок',
        'согласен',
        'я согласен',
    ]:
        res['response']['text'] ='Спасибо. Давайте начнем. Укажите причину обращения?'
        x+='Причина обращения - '
        return
    if req['request']['original_utterance'].lower() in [
        '\nДиагноз',
        'предварительный диагноз',

    ]:
        res['response']['text'] ='Слушаю:'
        x+='\nДиагноз - '
        return    
      
    if req['request']['original_utterance'].lower() in [
        'назначение',
        'препарат',
        'рекоммендации',
        'препараты',

    ]:
        res['response']['text'] ='Слушаю:'
        x+='назначение - '
        return
    if req['request']['original_utterance'].lower() in [
        'приём завершён',
        'приём завершен',
        'запись завершена',
        'досвидания',
    ]:
        res['response']['text'] ='Отлично! Вот что я записала:'+x
        return
    # Обрабатываем ответ пользователя.
    if req['request']['original_utterance'].lower() in [
        'всё',
        'это всё',
        'вроде всё',
        'закончил',
        'запись завершена',
    ]:
        # Пользователь согласился, прощаемся
        '''try:   
            addr_from = 'sseu.post@gmail.com'                 # Адресат
            addr_to   = 'dojdlivaia@gmail.com'                # Получатель
            password  = 'Nefig672'                            # Пароль

            msg = MIMEMultipart()                               # Создаем сообщение
            msg['From']    = addr_from                          # Адресат
            msg['To']      = addr_to                            # Получатель
            msg['Subject'] = 'Что-то  пошло так'                   # Тема сообщения

            body = req['request']['original_utterance']
            msg.attach(MIMEText(body, 'plain'))                 # Добавляем в сообщение текст

            server = smtplib.SMTP('smtp.gmail.com', 587)        # Создаем объект SMTP
            server.set_debuglevel(True)                         # Включаем режим отладки - если отчет не нужен, строку можно закомментировать
            server.starttls()                                   # Начинаем шифрованный обмен по TLS
            server.login(addr_from, password)                   # Получаем доступ
            server.send_message(msg)                            # Отправляем сообщение
            server.quit()
        except:
            pass# Выходим'''
    
        res['response']['text'] ='Спасибо, я всё записала '
        return

    # Если нет, записываем информацию!
    res['response']['text'] = 'Я записала "%s". Что-то ещё? ' % (
    req['request']['original_utterance']
    )
    x +=req['request']['original_utterance']+'; '
    res['response']['buttons'] = get_suggests(user_id)

# Функция возвращает две подсказки для ответа.
def get_suggests(user_id):
    session = sessionStorage[user_id]

    # Выбираем две первые подсказки из массива.
    suggests = [
        {'title': suggest, 'hide': True}
        for suggest in session['suggests'][:2]
    ]

    # Убираем первую подсказку, чтобы подсказки менялись каждый раз.
    if len(suggests) >= 2:
        session['suggests'] = session['suggests'][1:]
        sessionStorage[user_id] = session



    return suggests
#f=open('card.txt','r')
#y = f.read()

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        f = request.files['card.txt']
        f.save('https://yadi.sk/d/F1HI3ZLzhHSihw/uploaded_file.txt')

'''import datetime
d=datetime.datetime.today()
n=datetime.datetime.now() 
x=str(d.day)+'-'+str(d.month)+'-'+str(d.year)
data=x
time=str(n.hour)+':'+str(n.minute)
med_id='Поликлиника, № 15'
user_med_id='6b97429d-9a98-11e9-9ed4-001d7d98a0eb'
med_type='терапевт'
import json
user_id='c4bn7187-9a98-11e9-9ed4-001d7d98a0eb'
filename='data_'+user_id+'_'+data+'_'+str(n.hour)+'-'+str(n.minute)+'.json'
simp=input('simptomy')
diagnoz=input('diagnoz')
result=input('result')

with open(filename, mode='w', encoding='utf-8') as feedsjson:
    json.dump({'user_id': user_id, 'med_type':med_type,'med_id':med_id,'user_med_id':user_med_id,'data':data,'time':time,'simp': simp,'diagnoz':diagnoz,'result':result}, feedsjson)
'''
